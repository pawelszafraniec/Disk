﻿namespace Disk.Common.DTO
{
    public class UserResponse
    {
        public string? Login { get; set; }
        public string? Email { get; set; }
    }
}