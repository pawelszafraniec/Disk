﻿namespace Disk.Common
{
    public static class Cookies
    {
        public static readonly string Authentication = "Authentication";
    }
}
