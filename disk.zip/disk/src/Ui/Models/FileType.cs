﻿namespace Disk.Ui.Models
{
    public enum FileType
    {
        Unknown = 0,
        Image = 1,
        Text = 2,
        Video = 3,
    }
}
