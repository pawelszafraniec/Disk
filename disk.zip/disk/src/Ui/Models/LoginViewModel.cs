﻿namespace Disk.Ui.Models
{
    public class LoginViewModel
    {
        public string Login { get; set; } = "";

        public string? Message { get; set; } = null;
    }
}
