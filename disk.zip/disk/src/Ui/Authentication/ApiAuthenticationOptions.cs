﻿using Microsoft.AspNetCore.Authentication;

namespace Disk.Ui.Authentication
{
    public class ApiAuthenticationOptions : AuthenticationSchemeOptions
    {
    }
}